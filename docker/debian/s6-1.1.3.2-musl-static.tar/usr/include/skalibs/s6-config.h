/* ISC license. */

#ifndef S6_CONFIG_H
#define S6_CONFIG_H

#define S6_VERSION "1.1.3.2"

#define S6_BINPREFIX ""
#define S6_EXTBINPREFIX ""

#endif
