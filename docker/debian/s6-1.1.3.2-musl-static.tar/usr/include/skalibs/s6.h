/* ISC license. */

#ifndef S6_H
#define S6_H

#include "s6-supervise.h"

#endif
